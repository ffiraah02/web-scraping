"""
Slide 2-11 & 2-16 : Scraper pertama dengan urllib.request.urlopen
Hanya mengambil file HTML utama (belum otomatis mengambil CSS/JS/gambar).
"""
from urllib.request import urlopen

html = urlopen("http://pythonscraping.com/pages/page1.html")
content = html.read()
print(content)
