"""
Slide 2-9 & 2-10 : Requests Module
requests.get() mengirim HTTP request ke URL dan mengembalikan response.
"""
import requests

url = "http://pythonscraping.com/pages/page1.html"
res = requests.get(url, timeout=15)

print("Status code :", res.status_code)  # 200 = sukses
print("Content-Type:", res.headers.get("Content-Type"))
print("--- HTML (300 karakter pertama) ---")
print(res.text[:300])
