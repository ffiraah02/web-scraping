"""
Slide 2-17 s.d. 2-22 : Running BeautifulSoup
Latihan: soup.title, soup.find(), soup.find_all(), class_, get_text(strip=True)
"""
import requests
from bs4 import BeautifulSoup

URL = "http://pythonscraping.com/pages/page3.html"   # halaman latihan (tabel produk)

response = requests.get(URL, timeout=15)
soup = BeautifulSoup(response.text, "html.parser")   # membuat objek BeautifulSoup

# 1. Mengambil tag <title>
print("1. soup.title          :", soup.title)
print("   soup.title.string   :", soup.title.string)

# 2. find() -> elemen PERTAMA yang cocok
h1 = soup.find("h1")
print("2. find('h1')          :", h1.get_text(strip=True))

# 3. find() dengan atribut class_
judul_tabel = soup.find("table", id="giftList")
print("3. find(table#giftList):", "ditemukan" if judul_tabel else "tidak ada")

# 4. find_all() -> SEMUA elemen yang cocok (hasilnya list)
baris = soup.find_all("tr", class_="gift")
print(f"4. find_all('tr', class_='gift') -> {len(baris)} baris")

for item in baris:
    kolom = item.find_all("td")
    nama = kolom[0].get_text(strip=True)
    harga = kolom[2].get_text(strip=True)
    print("   -", nama, "|", harga)
