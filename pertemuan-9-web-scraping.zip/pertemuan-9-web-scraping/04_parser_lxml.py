"""
Slide 2-26 & 2-27 : Parser html.parser vs lxml
BeautifulSoup(html, "html.parser") -> parser bawaan Python
BeautifulSoup(html, "lxml")        -> parser populer lain (pip install lxml)
"""
import requests
from bs4 import BeautifulSoup

URL = "http://pythonscraping.com/pages/page1.html"
html = requests.get(URL, timeout=15).text

soup_bawaan = BeautifulSoup(html, "html.parser")
print("Dengan html.parser:", soup_bawaan.h1.get_text())

soup_lxml = BeautifulSoup(html, "lxml")
print("Dengan lxml       :", soup_lxml.h1.get_text())
