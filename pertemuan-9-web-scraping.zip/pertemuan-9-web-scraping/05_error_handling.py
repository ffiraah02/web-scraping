"""
Slide 2-28 s.d. 2-30 : Connecting & Exceptions
- Tangani error HTTP / server tidak ditemukan
- Tangani AttributeError jika tag tidak ada
- Retry mechanism agar scraper stabil
"""
import time

import requests
from bs4 import BeautifulSoup


def get_html(url, retries=3, delay=2):
    """Ambil HTML dengan retry. Kembalikan None jika semua percobaan gagal."""
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(url, timeout=15)
            response.raise_for_status()          # lempar HTTPError jika 4xx/5xx
            return response.text
        except requests.HTTPError as e:
            print(f"[HTTP Error] {e}")
            return None                          # 404 dsb tidak perlu di-retry
        except requests.ConnectionError:
            print(f"[Percobaan {attempt}/{retries}] Server tidak dapat ditemukan!")
        except requests.Timeout:
            print(f"[Percobaan {attempt}/{retries}] Request timeout.")
        time.sleep(delay)
    return None


def get_title(url):
    """Ambil <h1> dari halaman. Kembalikan None jika gagal/tidak ada."""
    html = get_html(url)
    if html is None:
        return None
    try:
        soup = BeautifulSoup(html, "html.parser")
        title = soup.body.h1
    except AttributeError:                       # misal tidak ada <body>
        return None
    return title


if __name__ == "__main__":
    # 1. URL valid
    title = get_title("http://www.pythonscraping.com/pages/page1.html")
    print("Hasil:", "Title could not be found" if title is None else title.get_text())

    # 2. URL tidak ada -> program tidak crash
    title = get_title("https://pythonscrapingthisurldoesnotexist.com")
    print("Hasil:", "Title could not be found" if title is None else title.get_text())
