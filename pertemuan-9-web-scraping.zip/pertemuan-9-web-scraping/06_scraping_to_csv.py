"""
Slide 2-23 : Scraping to CSV
Alur: Fetch -> Parse -> Store (unstructured data -> structured data)
"""
import requests
from bs4 import BeautifulSoup
import pandas as pd

URL = "http://pythonscraping.com/pages/page3.html"
OUTPUT = "data/produk.csv"

response = requests.get(URL, timeout=15)
response.raise_for_status()
soup = BeautifulSoup(response.text, "html.parser")

data = []
for row in soup.find_all("tr", class_="gift"):
    kolom = row.find_all("td")
    data.append(
        {
            "nama": kolom[0].get_text(strip=True),
            "deskripsi": kolom[1].get_text(strip=True),
            "harga": kolom[2].get_text(strip=True),
        }
    )

df = pd.DataFrame(data)
print(df)
df.to_csv(OUTPUT, index=False, encoding="utf-8-sig")
print(f"\nTersimpan: {OUTPUT} ({len(df)} baris)")
