"""
TUGAS MANDIRI - isi sesuai website target dari dosen / pilihan sendiri.
Periksa robots.txt & ketentuan situs sebelum scraping.

Langkah:
1. Inspect element (klik kanan -> Inspect) untuk mencari tag/class data yang dibutuhkan
2. Ubah URL, TAG, dan CLASS_NAME di bawah
3. Jalankan: python 07_tugas_mandiri.py
"""
import requests
from bs4 import BeautifulSoup
import pandas as pd

URL = "https://example.com"      # TODO: ganti dengan URL target
TAG = "p"                         # TODO: ganti tag yang dicari
CLASS_NAME = None                 # TODO: isi nama class jika perlu, mis. "judul"
OUTPUT = "data/hasil_tugas.csv"

headers = {"User-Agent": "Mozilla/5.0 (Tugas Kuliah Web Scraping)"}
response = requests.get(URL, headers=headers, timeout=15)
response.raise_for_status()
soup = BeautifulSoup(response.text, "html.parser")

elemen = soup.find_all(TAG, class_=CLASS_NAME) if CLASS_NAME else soup.find_all(TAG)
data = [{"teks": el.get_text(strip=True)} for el in elemen]

df = pd.DataFrame(data)
print(df)
df.to_csv(OUTPUT, index=False, encoding="utf-8-sig")
print(f"Tersimpan: {OUTPUT} ({len(df)} baris)")
