# Pertemuan 9 - Teknik Web Scraping (Requests & BeautifulSoup4)

Repository praktik mata kuliah **Social Media Analysis** (Bisnis Digital, FEB UNM),
berdasarkan materi *"Teknik Web Scraping"* (referensi: Ryan Mitchell, *Web Scraping with Python*, 2nd ed.).

## Konsep Singkat
Web scraping adalah proses otomatis mengambil data dari website: **Fetching → Parsing → Storing**
(→ opsional pindah ke halaman lain). Tujuannya mengubah *unstructured data* (HTML) menjadi
*structured data* (CSV, XML, SQL, XLS).

## Struktur Repository
| File | Materi (slide) | Isi |
|------|----------------|-----|
| `01_urllib_urlopen.py` | 2-11, 2-16 | Scraper pertama dengan `urllib.request.urlopen` |
| `02_requests_get.py` | 2-9, 2-10 | `requests.get()`, status code, isi HTML |
| `03_beautifulsoup_dasar.py` | 2-17 – 2-22 | `soup.title`, `find()`, `find_all()`, `class_`, `get_text(strip=True)` |
| `04_parser_lxml.py` | 2-26, 2-27 | Perbandingan parser `html.parser` vs `lxml` |
| `05_error_handling.py` | 2-28 – 2-30 | `HTTPError`, `AttributeError`, retry, graceful error handling |
| `06_scraping_to_csv.py` | 2-23 | Hasil scraping → pandas DataFrame → CSV |
| `07_tugas_mandiri.py` | - | Template tugas: ganti URL/tag/class sesuai target |
| `data/` | - | Folder output CSV |

## Cara Menjalankan
```bash
# 1. Clone
git clone https://github.com/<username>/pertemuan-9-web-scraping.git
cd pertemuan-9-web-scraping

# 2. Buat virtual environment (sesuai materi: nama envku)
python3 -m venv envku
source envku/bin/activate        # Mac/Linux
envku\Scripts\activate           # Windows

# 3. Install library
pip install -r requirements.txt

# 4. Jalankan per latihan
python 02_requests_get.py
python 03_beautifulsoup_dasar.py
python 06_scraping_to_csv.py
```

## Catatan Penting
- Virtual environment mencegah konflik antar library antar proyek.
- `requests.get(url)` hanya mengambil **file HTML utama**, bukan seluruh resource (CSS, JS, gambar).
- Halaman yang dimuat dengan JavaScript tidak terbaca oleh requests + BeautifulSoup
  (butuh Selenium/Playwright).
- Beri jeda antar request, cek `robots.txt`, dan jangan scraping data pribadi.
- Situs latihan: `pythonscraping.com` (dari buku Ryan Mitchell).

## Identitas
- Nama : Fauziah Indah Magfirah Yusuf
- NIM  : 240907502042
- Prodi: Bisnis Digital, FEB, Universitas Negeri Makassar
